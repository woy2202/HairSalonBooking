using HairSalon.Booking.Api.Data;
using HairSalon.Booking.Api.Infrastructure;
using HairSalon.Booking.Api.Options;
using HairSalon.Booking.Core.Events;
using HairSalon.Booking.Core.Models;
using HairSalon.Booking.Core.Patterns;
using HairSalon.Booking.Core.Repositories;
using HairSalon.Booking.Core.Services;
using Microsoft.Azure.Cosmos;

namespace HairSalon.Booking.Api.Infrastructure;

public static class ServiceCollectionExtensions
{
    public static IServiceCollection AddBookingApplication(this IServiceCollection services, IConfiguration configuration)
    {
        services.Configure<AzureBookingOptions>(configuration.GetSection("Azure"));
        services.AddSingleton<IBookingEntityFactory, BookingEntityFactory>();
        services.AddScoped<IPhotoStorageService, BlobPhotoStorageService>();
        services.AddScoped<IAppointmentBookingFacade, AppointmentBookingFacade>();
        services.AddScoped<IAppointmentBookedHandler, AzureBlobAppointmentSummaryHandler>();
        services.AddScoped<IAppointmentBookedHandler, AzureQueueAppointmentBookedHandler>();
        services.AddScoped<IBookingEventPublisher, BookingEventPublisher>();

        var options = configuration.GetSection("Azure").Get<AzureBookingOptions>() ?? new AzureBookingOptions();
        if (string.IsNullOrWhiteSpace(options.Cosmos.ConnectionString))
        {
            services.AddSingleton<IBookingRepository<Customer>, InMemoryBookingRepository<Customer>>();
            services.AddSingleton<IBookingRepository<Hairdresser>, InMemoryBookingRepository<Hairdresser>>();
            services.AddSingleton<IBookingRepository<SalonService>, InMemoryBookingRepository<SalonService>>();
            services.AddSingleton<IBookingRepository<Appointment>, InMemoryBookingRepository<Appointment>>();
            services.AddSingleton<IBookingRepository<SalonPhoto>, InMemoryBookingRepository<SalonPhoto>>();
            services.AddHostedService<SeedDataHostedService>();
            return services;
        }

        services.AddSingleton(_ => new CosmosClient(options.Cosmos.ConnectionString));
        services.AddSingleton(sp =>
        {
            var client = sp.GetRequiredService<CosmosClient>();
            var database = client.CreateDatabaseIfNotExistsAsync(options.Cosmos.DatabaseName).GetAwaiter().GetResult().Database;
            return database.CreateContainerIfNotExistsAsync(options.Cosmos.ContainerName, "/partitionKey").GetAwaiter().GetResult().Container;
        });
        services.AddScoped(typeof(IBookingRepository<>), typeof(CosmosBookingRepository<>));
        return services;
    }
}
